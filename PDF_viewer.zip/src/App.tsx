import * as React from "react";
import PdfViewer from "./components/pdfViewer";

const App = () => {

  return (
    <>
      <h1>Exemple pdf viewer</h1>
      <PdfViewer />
      <div>
        <h1>Some Footer</h1>
      </div>
    </>
  );
};

export default App;
